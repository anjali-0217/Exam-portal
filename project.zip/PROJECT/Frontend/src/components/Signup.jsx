import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import Validation from "../signupvalidation";
import "./Signup.css";
import examsapis from "../services/Examapis";

function Signup() {
  const [user, setUser] = useState({
    firstname: "",
    lastname: "",
    username: "",
    password: "",
    email: "",
    phone: "",
  });

  const navigate = useNavigate();
  const [errors, setErrors] = useState({});

  const handleInput = (e) => {
    const value = e.target.value;
    setUser({ ...user, [e.target.name]: value });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    examsapis.createUser(user)
      .then((response) => {
        setUser({
          firstname: "",
          lastname: "",
          username: "",
          password: "",
          email: "",
          phone: "",
        });
        alert("Account created Successfully ✅");
        navigate("/login");
        
      })
      .catch((err) => {
        alert("Account not created ");
        setErrors(Validation(errors));
        console.log(err);
      });
  };
  return (
    <div className="signup-container">
      <h1>Sign Up</h1>
      <form action="" onSubmit={handleSubmit}>
        <label>
          First name:
          <input
            type="text"
            placeholder="Enter your first name"
            name="firstname"
            value={user.firstname}
            onChange={(e) => handleInput(e)}
          />
          <br />
          {errors.firstname && (
            <span className="text-danger"> {errors.firstname}</span>
          )}
        </label>
        <label>
          Last name:
          <input
            type="text"
            placeholder="Enter your last name"
            name="lastname"
            value={user.lastname}
            onChange={(e) => handleInput(e)}
          />
          <br />
          {errors.lastname && (
            <span className="text-danger"> {errors.lastname}</span>
          )}
        </label>
        <label>
          Username:
          <input
            type="text"
            placeholder="Enter username"
            name="username"
            value={user.username}
            onChange={(e) => handleInput(e)}
          />
          <br />
          {errors.username && (
            <span className="text-danger"> {errors.username}</span>
          )}
        </label>
        <label>
          Password:
          <input
            type="password"
            placeholder="Enter password"
            name="password"
            onChange={(e) => handleInput(e)}
            value={user.password}
          />
          <br />
          {errors.password && (
            <span className="text-danger"> {errors.password}</span>
          )}
        </label>

        <label>
          Email id:
          <input
            type="email"
            placeholder="Enter email id"
            name="email"
            value={user.email}
            onChange={(e) => handleInput(e)}
          />
          <br />
          {errors.email && <span className="text-danger"> {errors.email}</span>}
        </label>
        <label>
          Phone no.:
          <input
            type="number"
            placeholder="Enter phone no."
            name="phone"
            value={user.phone}
            onChange={(e) => handleInput(e)}
          />
          <br />
          {errors.phone && <span className="text-danger"> {errors.phone}</span>}
        </label>
        <button type="submit">Sign Up</button>
      </form>
    </div>
  );
}

export default Signup;
