// src/App.js
import React, { useState } from 'react';
import { Link ,useNavigate} from "react-router-dom";
import Validation from '../loginvalidation';
import './login.css';

function Login () {
  const [user, setUser] = useState({
  username:'',
  password:''
  })

  const navigate = useNavigate();
  const [errors,setErrors]=useState({})
  
  const handleInput = (e) => {
    const value = e.target.value;
    setUser({ ...user, [e.target.name]: value });
  };

  const handleSubmit=(event)=>{
    event.preventDefault();
    // setErrors(Validation(values));
    if (user.username=="aditigiri04" && user.password=="aditigiri04") {
      alert("Welcome Admin");
      navigate("/sidebar");
    } else if (user.username=="anjali2003" && user.password=="2003") {
      navigate("/sidebar");
      alert("Welcome Admin");
    }
    else{
      navigate("/userdashboard");
    }
  }


  return (
    <div className='login'>
    <div className="login-container">
      <h1>Login</h1>
      <form action="" onSubmit={handleSubmit}>
        <label>
          Username:
          <input
            type="text"
            placeholder="Enter username"
            name='username'
            value={user.username}
            onChange={(e) => handleInput(e)}
          />
          <br/>
          {errors.username && <span className='text-danger'> {errors.username}</span>}
        </label>
        <label>
          Password:
          <input
            type="password"
            placeholder="Enter password"
            name='password'
            value={user.password}
            onChange={(e) => handleInput(e)}
          />
          <br/>
          {errors.password && <span className='text-danger'> {errors.password}</span>}
        </label>
        <button type="submit" >
          Continue
        </button>
        <p>Don't have an account?</p><Link to="/signup">Create an account</Link>
      </form>
    </div>
    </div>
  );
};

export default Login;
