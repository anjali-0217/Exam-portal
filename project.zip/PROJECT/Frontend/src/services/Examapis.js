import axios from 'axios';

const add = "http://localhost:9000/user/";
const login = "http://localhost:9000/generate-token";

class Examapis {

    createUser(user) {
        return axios.post(add,user);
    }

    // generateToken(user){
    //     return axios.post(login,user);
    // }

    // login(){
    //     return axios.post()
    // }

}

export default new Examapis();