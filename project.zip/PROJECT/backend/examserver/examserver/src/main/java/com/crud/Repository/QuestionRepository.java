package com.crud.Repository;

import com.crud.models.exam.Question;
import com.crud.models.exam.Quiz;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Set;

public interface QuestionRepository extends JpaRepository<Question, Long> {


    Set<Question> findByQuiz(Quiz quiz);
}
