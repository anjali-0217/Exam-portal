package com.crud.models.exam;

import static org.junit.jupiter.api.Assertions.*;

class CategoryTest {

}